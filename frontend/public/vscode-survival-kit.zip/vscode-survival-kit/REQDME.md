# ⚡ VS Code Survival Kit — Guide d'installation

Merci d'avoir téléchargé le kit ! Voici comment l'installer en 2 minutes :

## 1. Appliquer le `settings.json`
- Ouvre VS Code.
- Fais `Ctrl + Shift + P` (ou `Cmd + Shift + P` sur Mac).
- Tape `Open User Settings (JSON)`.
- Remplace ou fusionne le contenu avec le fichier `settings.json` fourni.

## 2. Installer les Snippets
- Fais `Ctrl + Shift + P` -> `Configure User Snippets`.
- Choisis `New Global Snippets file...` et nomme-le `web-snippets`.
- Colle le contenu de `web-snippets.code-snippets`.

## 3. Extensions recommandées
Installe directement depuis le Marketplace VS Code :
1 - GitHub pull requests
2 - luna paint - image editor
3 - github action
4 - Live Server
5 - Auto Rename Tag
6 - Auto Close Tag
7 - Tailwind CSS IntelliSense
8 - Prettier - Code formatter
9 - Color Highlight
10 - Bootstrap IntelliSense
11 - Dracula theme official
12 - Material Icon Theme
13 - Path Intellisense

## 3. Commande pour installer
code --install-extension codeium.codeium --install-extension bradlc.vscode-tailwindcss --install-extension esbenp.prettier-vscode --install-extension dracula-theme.theme-dracula --install-extension pkief.material-icon-theme --install-extension christian-kohler.path-intellisense --install-extension ritwickdey.liveserver --install-extension formulahendry.auto-rename-tag --install-extension formulahendry.auto-close-tag --install-extension naumovs.color-highlight --install-extension github.vscode-pull-request-github --install-extension github.vscode-github-actions --install-extension vsls-contrib.luna-paint